import React, { useState } from 'react';
import { useSkillAssessment } from '../../context/SkillAssessmentContext';
import { FileText, CheckCircle, AlertCircle, ArrowRight } from 'lucide-react';

export default function SkillTests() {
  const { 
    analyzedSkills = [], 
    generatedQuestions = [], 
    isAnalyzing = false, 
    testResult, 
    analyzeResumeAndGenerateTest, 
    calculateResult 
  } = useSkillAssessment() || {};

  const [resumeContent, setResumeContent] = useState('');
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [testStarted, setTestStarted] = useState(false);
  const [testSubmitted, setTestSubmitted] = useState(false);

  // Resume Analyze button trigger
  const handleStartAnalysis = (e) => {
    e.preventDefault();
    if (!resumeContent.trim()) return;
    if (analyzeResumeAndGenerateTest) {
      analyzeResumeAndGenerateTest(resumeContent);
    }
  };

  // Option select handler
  const handleOptionSelect = (questionId, optionIndex) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  // Final Test Submit
  const handleTestSubmit = () => {
    if (calculateResult) {
      calculateResult(selectedAnswers);
    }
    setTestSubmitted(true);
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <div className="border-b pb-4">
        <h1 className="text-2xl font-bold text-slate-800">AI Resume Skill Assessment</h1>
        <p className="text-xs text-slate-400">Paste your resume content to extract skills and take an adaptive test.</p>
      </div>

      {/* STEP 1: Resume Upload / Text Input */}
      {!testStarted && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 space-y-4 shadow-sm">
          <h2 className="text-sm font-bold text-slate-700 flex items-center gap-2">
            <FileText size={18} className="text-indigo-600" /> Step 1: Paste Resume Content or Keywords
          </h2>
          <textarea
            value={resumeContent}
            onChange={(e) => setResumeContent(e.target.value)}
            placeholder="Paste your resume summary, skills (e.g. React, JavaScript, Node.js), or work experience here..."
            className="w-full text-xs p-4 bg-slate-50 border border-slate-200 rounded-2xl h-36 focus:outline-none focus:border-indigo-500"
          />

          <button
            onClick={handleStartAnalysis}
            disabled={isAnalyzing || !resumeContent.trim()}
            className="bg-indigo-600 text-white text-xs font-semibold px-6 py-3 rounded-xl hover:bg-indigo-700 disabled:bg-slate-300 transition"
          >
            {isAnalyzing ? 'Analyzing Resume Skills...' : 'Analyze & Generate Test'}
          </button>

          {/* Extracted Skills Preview */}
          {analyzedSkills.length > 0 && !isAnalyzing && (
            <div className="mt-4 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-3">
              <p className="text-xs font-bold text-indigo-900">Extracted Skills Detected:</p>
              <div className="flex flex-wrap gap-2">
                {analyzedSkills.map((skill, idx) => (
                  <span key={idx} className="bg-indigo-600 text-white text-[11px] px-3 py-1 rounded-full font-semibold">
                    {skill}
                  </span>
                ))}
              </div>
              <button
                onClick={() => setTestStarted(true)}
                className="mt-2 bg-emerald-600 text-white text-xs font-semibold px-5 py-2.5 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition"
              >
                Start Adaptive Test <ArrowRight size={14} />
              </button>
            </div>
          )}
        </div>
      )}

      {/* STEP 2: Interactive Assessment Test */}
      {testStarted && !testSubmitted && (
        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-4 rounded-2xl flex justify-between items-center text-xs">
            <span>Evaluating Skills: <strong>{analyzedSkills.join(', ')}</strong></span>
            <span>Total Questions: <strong>{generatedQuestions.length}</strong></span>
          </div>

          {generatedQuestions.map((q, index) => (
            <div key={q.id || index} className="bg-white p-6 rounded-3xl border border-slate-200 space-y-3 shadow-sm">
              <h3 className="text-sm font-bold text-slate-800">
                Q{index + 1}. {q.question}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                {q.options.map((option, optIdx) => (
                  <button
                    key={optIdx}
                    onClick={() => handleOptionSelect(q.id || index, optIdx)}
                    className={`p-3 text-left rounded-xl text-xs border transition ${
                      selectedAnswers[q.id || index] === optIdx
                        ? 'border-indigo-600 bg-indigo-50 font-bold text-indigo-700'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          ))}

          <button
            onClick={handleTestSubmit}
            disabled={Object.keys(selectedAnswers).length < generatedQuestions.length}
            className="w-full bg-emerald-600 text-white font-bold text-xs py-3.5 rounded-xl hover:bg-emerald-700 disabled:bg-slate-300 transition"
          >
            Submit Skill Assessment
          </button>
        </div>
      )}

      {/* STEP 3: Assessment Results */}
      {testSubmitted && testResult && (
        <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-4 shadow-sm">
          {testResult.passed ? (
            <CheckCircle size={48} className="text-emerald-500 mx-auto" />
          ) : (
            <AlertCircle size={48} className="text-rose-500 mx-auto" />
          )}

          <h2 className="text-xl font-bold text-slate-800">
            {testResult.passed ? 'Skill Test Passed!' : 'Skill Assessment Needs Improvement'}
          </h2>

          <div className="flex justify-center gap-6 py-4">
            <div className="bg-slate-50 p-4 rounded-2xl border min-w-[120px]">
              <p className="text-[10px] text-slate-400 font-bold">SCORE</p>
              <p className="text-xl font-bold text-indigo-600">{testResult.percentage}%</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border min-w-[120px]">
              <p className="text-[10px] text-slate-400 font-bold">CORRECT</p>
              <p className="text-xl font-bold text-slate-700">{testResult.correctAnswers} / {testResult.totalQuestions}</p>
            </div>
          </div>

          <button
            onClick={() => {
              setTestStarted(false);
              setTestSubmitted(false);
              setSelectedAnswers({});
            }}
            className="bg-indigo-600 text-white text-xs font-bold px-6 py-2.5 rounded-xl hover:bg-indigo-700 transition"
          >
            Retake / Test Another Resume
          </button>
        </div>
      )}
    </div>
  );
}