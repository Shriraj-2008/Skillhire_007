import React, { useState } from 'react';
import { 
  Search, Bell, User, Briefcase, FileText, Bookmark, MessageSquare, 
  Settings, LogOut, ArrowLeft, ArrowRight, ChevronLeft, MoreVertical, 
  MapPin, Mail, Phone, ExternalLink, Download, Star, Calendar, 
  XCircle, Edit3, Save, CheckCircle2, BarChart2, Grid
} from 'lucide-react';
import CompanySidebar from '../../components/Company/CompanySidebar'; 
import CompanyNavbar from '../../components/Company/CompanyNavbar';// Import CompanySidebar component

export default function CandidateDetailsPage() {
  // 1. Dynamic Logged-in Recruiter / Company Profile State
  const [currentUser, setCurrentUser] = useState({
    companyName: '', // Dynamically updated via Login / Auth API
    role: '',
    isVerified: false
  });

  // Candidate Data State
  const [candidateData, setCandidateData] = useState({
    name: '',
    role: '',
    status: 'Active',
    location: '',
    email: '',
    phone: '',
    experience: '',
    educationTitle: '',
    lastActive: 'Today',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    tags: [],
    about: '',
    preferredRoles: [],
    expectedSalary: '',
    noticePeriod: '',
    skills: [],
    experienceHistory: [],
    educationHistory: [],
    projects: [],
    certificates: [],
    applicationDetails: {
      appliedFor: '',
      jobId: '',
      appliedOn: '',
      source: '',
      status: 'Active'
    },
    documents: [],
    notes: '',
    activityLogs: []
  });

  // Modal State & Selected Tab
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [formData, setFormData] = useState({ ...candidateData });
  const [activeTab, setActiveTab] = useState('Overview');

  // Input helper for array inputs in edit modal
  const [skillsInput, setSkillsInput] = useState('');

  const handleSaveDynamicData = (e) => {
    e.preventDefault();
    
    // Convert comma separated skills into standard array structure
    const updatedSkills = skillsInput
      ? skillsInput.split(',').map(s => ({ name: s.trim(), level: 'Proficient', percentage: 80 }))
      : formData.skills;

    const updatedData = {
      ...formData,
      skills: updatedSkills
    };

    setCandidateData(updatedData);
    setIsEditModalOpen(false);
  };

  const handleOpenEditModal = () => {
    setFormData({ ...candidateData });
    setSkillsInput(candidateData.skills.map(s => s.name).join(', '));
    setIsEditModalOpen(true);
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] font-sans text-slate-800 text-xs">
      
      {/* Sidebar Replaced with CompanySidebar */}

      {/* Main Container */}
      <div className="flex-1 flex flex-col overflow-hidden">
        
 

        {/* Dynamic Page Content */}
        <main className="flex-1 overflow-y-auto p-6 space-y-4">
          
          {/* Top Breadcrumb & Controls */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                <span>Dashboard</span> &gt; <span>Candidate Search</span> &gt; <span className="text-slate-800 font-medium">Candidate Details</span>
              </div>
              <div className="flex items-center gap-3">
                <button className="p-1.5 border bg-white rounded-lg hover:bg-slate-50"><ChevronLeft className="w-4 h-4 text-slate-600" /></button>
                <h1 className="text-xl font-bold text-slate-900">Candidate Details</h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={handleOpenEditModal}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
              >
                <Edit3 className="w-3.5 h-3.5" /> Edit / Dynamic Input
              </button>
              <button className="flex items-center gap-1 px-3 py-1.5 border bg-white text-indigo-600 rounded-lg font-medium hover:bg-slate-50"><ArrowLeft className="w-3.5 h-3.5" /> Previous</button>
              <button className="flex items-center gap-1 px-3 py-1.5 border bg-white text-indigo-600 rounded-lg font-medium hover:bg-slate-50">Next <ArrowRight className="w-3.5 h-3.5" /></button>
              <button className="p-2 border bg-white rounded-lg text-slate-500"><MoreVertical className="w-4 h-4" /></button>
            </div>
          </div>

          {/* Profile Header Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-center justify-between gap-6">
            <div className="flex items-center gap-5">
              <img src={candidateData.avatar} alt="Profile" className="w-20 h-20 rounded-full object-cover border-2 border-slate-100" />
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900">{candidateData.name || 'Candidate Name'}</h2>
                  {candidateData.status && (
                    <span className="bg-emerald-50 text-emerald-600 text-[10px] font-semibold px-2.5 py-0.5 rounded-full">{candidateData.status}</span>
                  )}
                </div>
                <p className="text-xs text-slate-500 font-medium">{candidateData.role || 'Designation / Role'}</p>
                <div className="flex flex-wrap items-center gap-4 text-slate-500 text-[11px] pt-1">
                  <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-slate-400" /> {candidateData.location || 'Location'}</span>
                  <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5 text-slate-400" /> {candidateData.email || 'Email'}</span>
                  <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-slate-400" /> {candidateData.phone || 'Phone'}</span>
                </div>
                <div className="flex items-center gap-4 text-slate-500 text-[11px] pt-1">
                  <span className="flex items-center gap-1"><Briefcase className="w-3.5 h-3.5 text-slate-400" /> {candidateData.experience || '0'} Years Experience</span>
                  <span className="flex items-center gap-1"><User className="w-3.5 h-3.5 text-slate-400" /> {candidateData.educationTitle || 'Education'}</span>
                </div>
                <div className="flex flex-wrap gap-1 pt-2">
                  {candidateData.tags.map((tag, i) => (
                    <span key={i} className="bg-indigo-50 text-indigo-600 text-[10px] px-2 py-0.5 rounded font-medium">{tag}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-right space-y-3 min-w-[120px]">
              <div>
                <span className="text-[10px] text-slate-400 font-medium block">Match Score</span>
                <div className="w-12 h-12 rounded-full border-2 border-emerald-500 flex items-center justify-center font-bold text-sm text-emerald-600 ml-auto mt-1">
                  {candidateData.matchScore}%
                </div>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Last Active</span>
                <span className="text-slate-700 font-medium">{candidateData.lastActive}</span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-slate-200 flex gap-6 text-xs">
            {['Overview', 'Resume', 'Skills & Tests', 'Experience', 'Education', 'Projects', 'Certificates', 'Activity'].map((tab) => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-2.5 font-medium border-b-2 transition ${activeTab === tab ? 'border-indigo-600 text-indigo-600 font-bold' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Dynamic Details Layout Grid */}
          <div className="grid grid-cols-12 gap-5">
            
            {/* Left Dynamic Details Sections based on Active Tab */}
            <div className="col-span-8 space-y-5">
              
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'Overview' && (
                <>
                  <div className="grid grid-cols-3 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
                    <div className="col-span-1 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">About</h3>
                      <p className="text-slate-500 text-[11px] leading-relaxed">{candidateData.about || 'No details provided yet.'}</p>
                      
                      <div className="pt-2">
                        <h4 className="font-bold text-slate-800 text-[11px]">Preferred Job Roles</h4>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {candidateData.preferredRoles.length > 0 ? (
                            candidateData.preferredRoles.map((role, idx) => (
                              <span key={idx} className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded text-[10px] font-medium">{role}</span>
                            ))
                          ) : <span className="text-slate-400">N/A</span>}
                        </div>
                      </div>

                      <div className="pt-1">
                        <span className="text-slate-400 text-[10px] block">Expected Salary</span>
                        <span className="font-bold text-slate-800 text-xs">{candidateData.expectedSalary || 'N/A'}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">Notice Period</span>
                        <span className="font-bold text-slate-800 text-xs">{candidateData.noticePeriod || 'N/A'}</span>
                      </div>
                    </div>

                    <div className="col-span-1 border-x border-slate-100 px-4 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">Skills</h3>
                      <div className="space-y-2">
                        {candidateData.skills.length > 0 ? candidateData.skills.map((skill, idx) => (
                          <div key={idx} className="space-y-0.5">
                            <div className="flex justify-between text-[10px]">
                              <span className="font-semibold text-slate-700">{skill.name}</span>
                              <span className="text-emerald-600 font-medium">{skill.level}</span>
                            </div>
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${skill.percentage || 80}%` }}></div>
                            </div>
                          </div>
                        )) : <p className="text-slate-400 text-[11px]">No skills listed</p>}
                      </div>
                    </div>

                    <div className="col-span-1 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">Recent Experience</h3>
                      <div className="space-y-3">
                        {candidateData.experienceHistory.length > 0 ? candidateData.experienceHistory.map((exp, idx) => (
                          <div key={idx} className="relative pl-4 border-l border-slate-200 space-y-0.5">
                            <span className="w-2 h-2 rounded-full border border-indigo-600 bg-white absolute -left-1 top-1"></span>
                            <h4 className="font-bold text-slate-800 text-[11px]">{exp.title}</h4>
                            <p className="text-slate-500 text-[10px]">{exp.company}</p>
                            <p className="text-slate-400 text-[9px]">{exp.duration}</p>
                          </div>
                        )) : <p className="text-slate-400 text-[11px]">No experience history available</p>}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">Education</h3>
                      {candidateData.educationHistory.length > 0 ? candidateData.educationHistory.map((edu, i) => (
                        <div key={i} className="space-y-1">
                          <h4 className="font-bold text-slate-800 text-[11px]">{edu.degree}</h4>
                          <p className="text-slate-400 text-[10px]">{edu.year}</p>
                          <p className="text-slate-500 text-[10px]">{edu.college}</p>
                          {edu.score && <span className="inline-block bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 rounded">{edu.score}</span>}
                        </div>
                      )) : <p className="text-slate-400 text-[11px]">No education details</p>}
                    </div>

                    <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">Projects</h3>
                      {candidateData.projects.length > 0 ? candidateData.projects.map((proj, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-slate-800 text-[11px]">{proj.title}</h4>
                            <ExternalLink className="w-3 h-3 text-indigo-600 cursor-pointer" />
                          </div>
                          <p className="text-slate-500 text-[10px] line-clamp-2">{proj.desc}</p>
                        </div>
                      )) : <p className="text-slate-400 text-[11px]">No projects added</p>}
                    </div>

                    <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                      <h3 className="font-bold text-slate-900 text-xs">Certificates</h3>
                      {candidateData.certificates.length > 0 ? candidateData.certificates.map((cert, i) => (
                        <div key={i} className="space-y-0.5">
                          <h4 className="font-bold text-slate-800 text-[11px]">{cert.name}</h4>
                          <p className="text-slate-400 text-[10px]">{cert.issuer}</p>
                        </div>
                      )) : <p className="text-slate-400 text-[11px]">No certificates listed</p>}
                    </div>
                  </div>
                </>
              )}

              {/* TAB 2: RESUME */}
              {activeTab === 'Resume' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h3 className="font-bold text-slate-900 text-sm">Resume / CV</h3>
                    {candidateData.documents.length > 0 && (
                      <button className="flex items-center gap-1.5 bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-indigo-700">
                        <Download className="w-3.5 h-3.5" /> Download Full Resume
                      </button>
                    )}
                  </div>
                  {candidateData.documents.length > 0 ? (
                    <div className="space-y-3">
                      {candidateData.documents.map((doc, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                          <div>
                            <p className="font-semibold text-slate-800">{doc.name}</p>
                            <p className="text-[10px] text-slate-400">PDF Document</p>
                          </div>
                          <Download className="w-4 h-4 text-indigo-600 cursor-pointer" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center text-slate-400 border border-dashed rounded-xl">
                      NO RESUME UPLOADED
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: SKILLS & TESTS */}
              {activeTab === 'Skills & Tests' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Skills & Evaluation Tests</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {candidateData.skills.length > 0 ? candidateData.skills.map((skill, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-800">{skill.name}</span>
                          <span className="bg-emerald-100 text-emerald-700 font-bold px-2 py-0.5 rounded text-[10px]">{skill.level}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-1">
                          <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${skill.percentage || 80}%` }}></div>
                        </div>
                      </div>
                    )) : <p className="text-slate-400 col-span-2">No skills provided.</p>}
                  </div>
                </div>
              )}

              {/* TAB 4: EXPERIENCE */}
              {activeTab === 'Experience' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Work Experience Timeline</h3>
                  <div className="space-y-4">
                    {candidateData.experienceHistory.length > 0 ? candidateData.experienceHistory.map((exp, idx) => (
                      <div key={idx} className="relative pl-6 border-l-2 border-indigo-600 space-y-1">
                        <span className="w-3 h-3 rounded-full bg-indigo-600 absolute -left-[7px] top-1"></span>
                        <h4 className="font-bold text-slate-900 text-xs">{exp.title}</h4>
                        <p className="text-slate-600 font-medium text-[11px]">{exp.company}</p>
                        <p className="text-slate-400 text-[10px]">{exp.duration}</p>
                      </div>
                    )) : <p className="text-slate-400">No work experience entries available.</p>}
                  </div>
                </div>
              )}

              {/* TAB 5: EDUCATION */}
              {activeTab === 'Education' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Education Qualifications</h3>
                  <div className="space-y-3">
                    {candidateData.educationHistory.length > 0 ? candidateData.educationHistory.map((edu, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <h4 className="font-bold text-slate-800 text-xs">{edu.degree}</h4>
                        <p className="text-slate-600">{edu.college}</p>
                        <p className="text-slate-400 text-[10px]">{edu.year}</p>
                      </div>
                    )) : <p className="text-slate-400">No education entries found.</p>}
                  </div>
                </div>
              )}

              {/* TAB 6: PROJECTS */}
              {activeTab === 'Projects' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Key Projects</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {candidateData.projects.length > 0 ? candidateData.projects.map((proj, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <div className="flex justify-between items-center">
                          <h4 className="font-bold text-slate-800">{proj.title}</h4>
                          <ExternalLink className="w-3.5 h-3.5 text-indigo-600 cursor-pointer" />
                        </div>
                        <p className="text-slate-500 text-[11px]">{proj.desc}</p>
                      </div>
                    )) : <p className="text-slate-400 col-span-2">No projects listed.</p>}
                  </div>
                </div>
              )}

              {/* TAB 7: CERTIFICATES */}
              {activeTab === 'Certificates' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Certifications & Licenses</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {candidateData.certificates.length > 0 ? candidateData.certificates.map((cert, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <h4 className="font-bold text-slate-800">{cert.name}</h4>
                        <p className="text-slate-500 text-[10px]">Issued by: {cert.issuer}</p>
                      </div>
                    )) : <p className="text-slate-400 col-span-2">No certificates found.</p>}
                  </div>
                </div>
              )}

              {/* TAB 8: ACTIVITY */}
              {activeTab === 'Activity' && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm border-b pb-3">Recent Candidate Activity</h3>
                  <div className="space-y-2">
                    {candidateData.activityLogs && candidateData.activityLogs.length > 0 ? (
                      candidateData.activityLogs.map((log, idx) => (
                        <div key={idx} className="p-2.5 bg-slate-50 rounded-lg text-slate-600 flex justify-between items-center">
                          <span>{log.action}</span>
                          <span className="text-[10px] text-slate-400">{log.time}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-slate-400">NO ACTIVITY</p>
                    )}
                  </div>
                </div>
              )}

            </div>

            {/* Right Panel Actions & Info */}
            <div className="col-span-4 space-y-4">
              
              {/* Actions Box */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-800 text-xs mb-2">Actions</h3>
                <button className="w-full py-2 bg-indigo-600 text-white rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-indigo-700">
                  <Star className="w-3.5 h-3.5" /> Shortlist Candidate
                </button>
                <button className="w-full py-2 border border-slate-200 rounded-lg font-medium text-slate-700 flex items-center justify-center gap-2 hover:bg-slate-50">
                  <Calendar className="w-3.5 h-3.5" /> Schedule Interview
                </button>
                <button className="w-full py-2 border border-slate-200 rounded-lg font-medium text-slate-700 flex items-center justify-center gap-2 hover:bg-slate-50">
                  <MessageSquare className="w-3.5 h-3.5" /> Send Message
                </button>
                <button className="w-full py-2 border border-slate-200 rounded-lg font-medium text-slate-700 flex items-center justify-center gap-2 hover:bg-slate-50">
                  <Download className="w-3.5 h-3.5" /> Download Resume
                </button>
                <button className="w-full py-2 border border-red-200 text-red-600 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-red-50">
                  <XCircle className="w-3.5 h-3.5" /> Reject Candidate
                </button>
              </div>

              {/* Application Details */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2.5">
                <h3 className="font-bold text-slate-800 text-xs">Application Details</h3>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between"><span className="text-slate-400">Applied For</span><span className="font-medium text-slate-800">{candidateData.applicationDetails.appliedFor || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Job ID</span><span className="font-medium text-slate-800">{candidateData.applicationDetails.jobId || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Applied On</span><span className="font-medium text-slate-800">{candidateData.applicationDetails.appliedOn || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Source</span><span className="font-medium text-slate-800">{candidateData.applicationDetails.source || 'N/A'}</span></div>
                  <div className="flex justify-between items-center"><span className="text-slate-400">Current Status</span><span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 rounded">{candidateData.applicationDetails.status || 'Active'}</span></div>
                </div>
              </div>

              {/* Documents */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-800 text-xs">Documents</h3>
                <div className="space-y-1.5">
                  {candidateData.documents.length > 0 ? (
                    candidateData.documents.map((doc, i) => (
                      <div key={i} className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500">{doc.name}</span>
                        <Download className="w-3.5 h-3.5 text-indigo-600 cursor-pointer" />
                      </div>
                    ))
                  ) : (
                    <span className="text-slate-400 text-[11px]">No documents attached</span>
                  )}
                </div>
              </div>

              {/* Notes */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-800 text-xs">Notes</h3>
                <textarea 
                  value={candidateData.notes} 
                  onChange={(e) => setCandidateData({ ...candidateData, notes: e.target.value })} 
                  placeholder="Add private recruiter notes here..." 
                  className="w-full bg-slate-50 border border-slate-200 p-2 rounded-lg text-xs outline-none h-20 resize-none"
                />
              </div>

            </div>

          </div>

        </main>
      </div>

    </div>
  );
}